import type React from "react"
import type { Language } from "../../types"
import { TEXTS, SERVICES_DATA } from "../../constants/texts"
import { ServiceCard } from "../ServiceCard/ServiceCard"
import css from "./Services.module.css"

interface ServicesProps {
  language: Language
}

export const Services: React.FC<ServicesProps> = ({ language }) => {
  return (
    <section className={`${css.services} section`} id="services">
      <div className={css.container}>
        <div className={css.textCenter}>
          <p className={css.sectionSubtitle}>{TEXTS.services[language]}</p>
          <h2 className={css.sectionTitle}>{TEXTS.exclusiveTreatments[language]}</h2>
        </div>
        <div className={css.servicesContainer}>
          {SERVICES_DATA.map((service) => (
            <ServiceCard key={service.id} service={service} language={language} />
          ))}
        </div>
      </div>
    </section>
  )
}
