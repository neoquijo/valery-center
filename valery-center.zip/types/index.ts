export interface ServiceCategory {
  id: string
  name: {
    ru: string
    en: string
  }
  description?: {
    ru: string
    en: string
  }
  images: string[]
  icon: string
  subcategories?: ServiceSubcategory[]
}

export interface ServiceSubcategory {
  id: string
  name: {
    ru: string
    en: string
  }
  description?: {
    ru: string
    en: string
  }
  images: string[]
  price?: {
    ru: string
    en: string
  }
}

export type Language = "ru" | "en"

export interface TextContent {
  ru: string
  en: string
}
